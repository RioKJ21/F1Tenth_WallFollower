#include <cstdio>
#include <string.h>
#include <stdint.h>
#include <vector>
#include <algorithm>

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <sensor_msgs/msg/laser_scan.hpp>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2/LinearMath/Quaternion.h>
#include <memory>
#include <math.h>

/*Most likely in m/s*/
#define LINEAR_VELOCITY 0.03 //When cmd_vel_angular_z is in the range of "-1 to 1"
#define SLOW_LINEAR_VELOCITY 0.02 //When cmd_vel_angular_z is in the range of "-1.81 to -1" and "1.81 to 1"
#define SLOWER_LINEAR_VELOCITY 0.01 //When cmd_vel_angular_z is "<< -1.81" and ">> 1.81"

/*Most likely in rad/s*/
#define ANGULAR_VELOCITY 1.82

/* Radiant to Degree and vice versa*/
#define RAD2DEG(x) ((x)*180. / M_PI)
#define DEG2RAD(x) ((x)*M_PI / 180.)

using namespace std::chrono_literals;

class right_wall_follower : public rclcpp::Node
{
public:
  right_wall_follower()
      : Node("right_wall_follower_drive_node")
  {

    auto qos = rclcpp::QoS(rclcpp::KeepLast(10));

    // Initialise publishers
    cmd_vel_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", qos);

    // Initialize subscribers
    scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
        "scan",
        rclcpp::SensorDataQoS(),
        std::bind(
            &right_wall_follower::scan_callback,
            this,
            std::placeholders::_1));
    
    /************************************************************
    ** Initialise ROS timers
    ************************************************************/
    update_timer_ = this->create_wall_timer(10ms, std::bind(&right_wall_follower::update_callback, this));

    RCLCPP_INFO(this->get_logger(), "Wall follower right drive node has been initialized");
  }

private:

  float right_side;
  float left_side;
  float front_right_side;
  float front_left_side;
  float range_min;
  float range_max;

  int count_ = 0;

  float theta1;
  float theta2;

  float min_val_;
  float max_val_;
  float kp_;
  float ki_;
  float kd_;
  double integral_;
  double derivative_;
  double prev_error_;
  
  // ROS timer
  rclcpp::TimerBase::SharedPtr update_timer_;

  int count1;
  int count2;
  int count3;
  int count4;
  
  float sum1;
  float sum2;
  float sum3;
  float sum4;
  
  float range1;
  float range2;
  float range3;
  float range4;
  
  float distance1;
  float distance2;
  
  float dright;
  float dleft;

  float diff;

  float degree1;
  float degree2;
  float degree3;
  float degree4;
  
  float alfa1;
  float alfa2;
  
  float last_sum1;
  float last_count1;
  float last_sum2;
  float last_count2;
  
  float last_sum3;
  float last_count3;
  float last_sum4;
  float last_count4;
  

  float front_view;

  void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
  { 
    count1 = 0;
    count2 = 0;
    count3 = 0;
    count4 = 0;
    
    sum1 = 0;
    sum2 = 0;
    sum3 = 0;
    sum4 = 0;
    
    range1 = 0;
    range2 = 0;
    range3 = 0;
    range4 = 0;
    
    diff = 1;

    degree1 = -90.0; // value of b
    degree2 = -30.0; // value of a
    degree3 = 90.0; // value of x
    degree4 = 30.0; //value of y

    std::vector<float> laser_ranges;
    laser_ranges = msg->ranges;
    
      /****************************************************************** NOTES *********************************************************************
      Variable		# Definition								: Value From Testing	@ Status
      
      angle_min		# Start angle of the scan (rad)						: -1.57 to -2 to -3.13	@ Changing, detail in galery	
      angle_increment	# Angular distance between measurements of 2 points (Theta) (rad)	: 0.0209 to 0.0215	@ Changing, detail in galery
      time_increment	# Time between measurements and interpolating position of 3D points (s)	: 0.00033 to 0.00024	@ Changing, detail in galery
      scan_time		# Time between scans (s)						: 0.071			@ Fix 
      range_max		# Maximum range value (m)						: 16.000000 (m)		@ Fix
      range_min		# Minimum range value (m)						: 0.150000 (m)		@ Fix
      ranges		# Range data (m)							:			@ Changing
      
      (Note: values < range_min or > range_max should be discarded) for ranges
      
      source taken from:
      http://docs.ros.org/en/melodic/api/sensor_msgs/html/msg/LaserScan.html
      **********************************************************************************************************************************************/
    
    /*for (int i = 0; i < laser_ranges.size(); i++) //Stop at element 294 & 289
    {
      printf("The Laser_Range value of element %d is %f\n", i, laser_ranges[i]);
    }*/

    right_side = 0.0;
    range_max = msg->range_max;
    range_min = msg->range_min;
    
    int count = msg->scan_time / msg->time_increment;
    
    /* FOR LOOP*/
    for (int i = 0; i < count; i++)
    {
    
      float degree = RAD2DEG(msg->angle_min + msg->angle_increment * i);
      
      printf("For element %d, Count value is %d and Degree value is %f\n", i, count, degree);    
      
      /**********************************
      ** When DEGREE is between -1 & 1 **
      **********************************/
      if (degree > -1.0 && degree < 1.0) 
      {
        if (laser_ranges[i] > 0)	
        {
          front_view = laser_ranges[i];
        }
        else
        {
          front_view = range_max;
        }
      }

      /*************************************
      ** When DEGREE is NOT between -89 & -91 **
      *************************************/
      if (degree < (degree1 + diff) && degree > (degree1 - diff)) //degree1 = -90.0
      {   
        if (laser_ranges[i] > 0)
        {
          sum1 = sum1 + msg->ranges[i]; //sum1 initially = 0
          count1++; //count1 initially = 0
          last_sum1 = sum1;
          last_count1 = count1;
        }
        else
        {
          sum1 = last_sum1;
          count1 = last_count1;
          // printf("%f\n", msg->ranges[i]);
          // printf("no wall detected\n");
        }
      }

      /*************************************
      ** When DEGREE is NOT between -29 & -31 **
      *************************************/
      if (degree < (degree2 + diff) && degree > (degree2 - diff)) //degree2 = -30.0
      {
        if (laser_ranges[i] > 0)
        {
          sum2 = sum2 + msg->ranges[i];
          count2++;
          last_sum2 = sum2;
          last_count2 = count2;
        }
        else
        {
          sum2 = last_sum2;
          count2 = last_count2;
        }
      }
      /*****************************************
      ** When DEGREE is NOT between 89 & 91 **
      ******************************************/
      if (degree < (degree3 + diff) && degree > (degree3 - diff)) //degree3 = 90.0
      {   
        if (laser_ranges[i] > 0)
        {
          sum3 = sum3 + msg->ranges[i]; //sum1 initially = 0
          count3++; //count1 initially = 0
          last_sum3 = sum3;
          last_count3 = count3;
        }
        else
        {
          sum3 = last_sum3;
          count3 = last_count3;
          // printf("%f\n", msg->ranges[i]);
          // printf("no wall detected\n");
        }
      }
      
      /*****************************************
       ** When DEGREE is NOT between 29 & 31 **
      *****************************************/
      if (degree < (degree4 + diff) && degree > (degree4 - diff)) //degree4 = 30.0
      {
        if (laser_ranges[i] > 0)
        {
          sum4 = sum4 + msg->ranges[i];
          count4++;
          last_sum4 = sum4;
          last_count4 = count4;
        }
        else
        {
          sum4 = last_sum4;
          count4 = last_count4;
        }
      }
    }

    range1 = sum1 / count1; //Degree -90 for value b
    range2 = sum2 / count2; // Degree -30 for value a
    range3 = sum3 / count3; //Degree 90 for value x
    range4 = sum4 / count4; // Degree 30 for value y
    
    //printf("Range1 b value is %f\n", range1);
    //printf("Range2 a value is %f\n", range2);
    //printf("Range3 x value is %f\n", range3);
    //printf("Range4 y value is %f\n", range4);
    
    right_side = range1; 
    front_right_side = range2;
    left_side = range3;
    front_left_side = range4;

    theta1 = degree2 - degree1; //-30 - -90 = 60
    theta2 = degree4 - degree3; //30 - 90 = -60
    
    float a = range2 * cos(DEG2RAD(theta1)); // To find range1
    float b = range2 * sin(DEG2RAD(theta1)); // To find height of the two scanned point b and a
    
    float e = range4 * cos(DEG2RAD(theta2)); // To find range3
    float f = range4 * sin(DEG2RAD(theta2)); // To find height of the two scanned point f and e
    
    alfa1 = RAD2DEG(atan((a - range1) / (b)));
    alfa2 = RAD2DEG(atan((e - range3) / (f)));

    distance1 = range1 * cos(DEG2RAD(alfa1)); // instance distance between center of the lidar with right wall
    distance2 = range3 * cos(DEG2RAD(alfa2)); // instance distance between center of the lidar with left wall

    float c = 0.3; // distance for prediction (In picture, it is called by "L")

    dright = distance1 + c * sin(DEG2RAD(alfa1)); // Distance to the right wall in future c
    dleft = distance2 + c * sin(DEG2RAD(alfa2)); // Distance to the left wall in future c
  }

  // Function prototypes
  void update_callback()
  {
    float wall_distance = (dright + dleft) / 2; //Desired distance to the side wall
    float front_dist = 2.0; //Desired distance to the front wall

    double error;
    double pid;
    
    /***************************************************************
    Turtlebot3 Waffle Pi
    
    Maximum translational velocity	: 0.26 m/s
    Maximum rotational velocity 	: 1.82 rad/s (104.27 deg/s)
    ****************************************************************/
    min_val_ = -1.82;
    max_val_ = 1.82; 
    
    kp_ = 0.6;
    ki_ = 0.0;
    kd_ = 20.0;

    // setpoint is constrained between min and max to prevent pid from having too much error
    // if (d1 > 0)
    // {
    
    /*Difference between the desired and actual values is the proportional error. It is used to calculate the control output, which is the steering angle.*/
    error = wall_distance - dright;
    
    //To eliminate steady state error (error)
    integral_ += error; 
    
    //To reduce overshoot and improve the speed of the controller's response
    derivative_ = error - prev_error_;
    
    if (wall_distance == 0 && error == 0) 
    {
      integral_ = 0;
    }

    pid = (kp_ * error) + (ki_ * integral_) + (kd_ * derivative_);
    prev_error_ = error;

    if (pid > max_val_)
    {
      pid = max_val_;
    }

    if (pid < min_val_)
    {
      pid = min_val_;
    }
    
    if (front_view <= front_dist) 
    {
      turn_left(1.82);
    }

    else
    {
      if (pid > 1.0 || pid < -1.0) 
      {
        follow_wall_slow(pid);
      }

      else if (pid > 1.81 || pid < -1.81)
      {
        follow_wall_slower(pid);
      }

      else
      {
        follow_wall(pid);
      }
    }

    RCLCPP_INFO(this->get_logger(), "%f,%f,%f,%f,%f", front_view, dright, dleft, wall_distance, pid);
    
    /****************** Notes ***********************
    Name                    Location                 
    
    front_view              front(no block)
    d1                      right
    laser_ranges            LEFT and behind (block)       
    ************************************************/
  }

  void update_cmd_vel(double linear, double angular)
  {
    geometry_msgs::msg::Twist cmd_vel;
    cmd_vel.linear.x = linear;
    cmd_vel.angular.z = angular;

    cmd_vel_pub_->publish(cmd_vel);
  }

  
  void turn_left(float ang)
  {
    update_cmd_vel(SLOWER_LINEAR_VELOCITY, ang); //0.01
  }
  
  void follow_wall(float ang)
  {
    update_cmd_vel(LINEAR_VELOCITY, ang); //0.03
  }
  
  void follow_wall_slow(float ang)
  {
    update_cmd_vel(SLOW_LINEAR_VELOCITY, ang); //0.02
  }
  
  void follow_wall_slower(float ang)
  {
    update_cmd_vel(SLOWER_LINEAR_VELOCITY, ang); //0.01
  }


  /****************************************************************
  void full_stop()
  {
    update_cmd_vel(0.0, 0.0);
  }
  
  void find_wall()
  {
    update_cmd_vel(LINEAR_VELOCITY, 0.0); //0.03
  }
  
  void turn_right(float ang)
  {
    update_cmd_vel(SLOW_LINEAR_VELOCITY, -1 * ang); //0.02
  }
  
  void move_backward()
  {
    update_cmd_vel(-1.0 * LINEAR_VELOCITY, 0.0); //0.03
  }
  **************************************************************/


  // ROS topic publishers
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  // rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;

  // ROS topic subscribers
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<right_wall_follower>());
  rclcpp::shutdown();

  return 0;
}
