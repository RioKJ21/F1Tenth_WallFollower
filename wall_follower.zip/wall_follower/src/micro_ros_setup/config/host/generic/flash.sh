echo "Nothing to flash: running in host mode"
echo "Use 'RMW_IMPLEMENTATION=rmw_microxrcedds ros2 run micro_ros_demos_rcl int32_subscriber' to start with examples"