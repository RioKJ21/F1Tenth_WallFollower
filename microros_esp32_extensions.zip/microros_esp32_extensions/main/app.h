#ifndef _MAIN_H_
#define _MAIN_H_

void appMain(void *argument);

#endif // _MAIN_H_
