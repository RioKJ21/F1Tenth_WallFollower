# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for __ldgen_output_esp32.project.ld.
